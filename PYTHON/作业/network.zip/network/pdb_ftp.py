from ftplib import FTP

#directories of data coming from and putting to
storedir='D:/pdb'
basedir='pub/pdb/data/structures/divided/pdb'
#connect to remote server
ftp=FTP('ftp.rcsb.org')
ftp.login()
ftp.cwd(basedir)
#ftp.dir()
#alst=ftp.nlst()
#bigin to download
#print 'README'
#ftp.retrbinary('RETR README', open(storedir+'/'+'README','wb').write)
pdbid = '222d' #可以尝试其它PDB编号 
pdbfl = 'pdb' + pdbid + '.ent.gz'
ftp.cwd(pdbid[1:3])
ftp.retrbinary('RETR %s'%pdbfl, open(storedir + '/' + pdbfl, 'wb').write)
ftp.quit()
print('done! (^_^)')
