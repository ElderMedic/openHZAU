#Server
import socket
s = socket.socket()
host = socket.gethostname()
port = 1234
addr = (host, port)
s.bind(addr)
s.listen(5)
while True:
  c, addr = s.accept()
  print('Got connection from', addr)
  message = 'Thank you for connecting!'
  c.send(bytes(message,encoding='UTF8'))
  c.close()
