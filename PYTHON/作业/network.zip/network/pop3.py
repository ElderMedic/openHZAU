#This is a demo program for geting emails from pop3 server
#Author: Bin-Guang Ma; Date: 2015-12-24; Modified on: 2018-12-07

import poplib
from time import sleep

#login mail server
M=poplib.POP3('pop.163.com', port=110)
M.user('mbgmbg')
M.pass_('xxxxxx')

#get the message count
Mes_num=M.stat()[0]
print('mail number: %s' %Mes_num)

if Mes_num>=1:
    for i in range(Mes_num):
        mes = M.retr(i+1)[1]
        print(mes[0])
        #M.dele(i+1)
        sleep(10)
        if i>3: break
else:
    print('No mail.')

M.quit()

print('done! (^_^)')
