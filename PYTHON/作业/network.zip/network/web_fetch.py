from urllib.request import urlopen
doc = urlopen("http://www.baidu.com")
text = doc.read()
print(text[:200])      
doc.close()
f = open('D:/temfile.txt', 'wt')
f.write(str(text))
f.close()
