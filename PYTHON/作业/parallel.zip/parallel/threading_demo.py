#This is a demo program for using threading.
#Adopted from <Python Core Programming>.
#Modified on: 2018-12-11

import threading
from time import sleep, ctime

loops = [4,2]

def loop(nloop, nsec):
    print('start loop', nloop, 'at:', ctime())
    sleep(nsec)
    print('loop', nloop, 'done at:', ctime())


print('starting at:', ctime())

threads = []
nloops = range(len(loops))

for i in nloops:
    t = threading.Thread(target=loop, args=(i, loops[i]))
    threads.append(t)

for i in nloops:
    threads[i].start()

for i in nloops:
    threads[i].join()

print('All Done at:', ctime())
