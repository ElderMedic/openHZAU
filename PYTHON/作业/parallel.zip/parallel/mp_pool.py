#This is a demo program for using multiprocessing
#Adopted from Help Doc.
#Modified on: 2018-12-11

from multiprocessing import Pool

def f(x):
    return x*x

if __name__ == '__main__':
    pool = Pool(processes=4)     # start 4 worker processes    
    print(pool.map(f, range(10)))    # prints "[0, 1, 4,..., 81]"
