#This is a demo program for using ppserver.
#Author: Bin-Guang Ma; Date: 2015-12-30

import pp
from time import ctime

job_server = pp.Server()
ncpus = job_server.get_ncpus()
job_server.destroy()

print 'Your machine has', ncpus, 'CPUs.'

from math import sin

sinsum = 0.0
print 'Start at:', ctime()
for i in xrange(1000000):
    sinsum += sin(i**5)*sin(i**4)*sin(i**3)*sin(i**2)*sin(i)
print 'sinsum =', sinsum
print 'End at:', ctime()

#using ppserver
def calc_sin(arange):
    from math import sin
    sinsum = 0.0
    for i in arange:
        sinsum += sin(i**5)*sin(i**4)*sin(i**3)*sin(i**2)*sin(i)
    return sinsum

job_server = pp.Server(ncpus)
print 'Starting pp with', ncpus, 'workers.'
print 'Now is', ctime() 
ranges = [range(0,250000),range(250000,500000),range(500000,750000),range(750000,1000000)]
jobs = [job_server.submit(calc_sin, (arange,)) for arange in ranges]
rst = []
map(lambda x: rst.append(x()),jobs)
job_server.print_stats()
job_server.destroy()
print 'sinsum =', sum(rst)
print 'Now is', ctime()

print 'done!(^_^)'

