#include <iostream>
using namespace std;
void times3(int arr[], int size);

void times3(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        arr[i] *= 3;
    }
}

int main() {
    int num[30];
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> num[i];
    }
    times3(num, n);
    for (int i = 0; i < n; i++) {
        cout << num[i] << ' ';
    }
    return 0;
}