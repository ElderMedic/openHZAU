#include<iostream>
using namespace std;

class Rectangle{
private:
  float length;
  float width;
public:
  void set(float l,float w);
  float acreage();
};

void Rectangle::set(float l, float w){
  if(l>=0 && l<=10) length = l;
  else length=1;
  if(w>=0 && w<=10) width = w;
  else width = 1;
}

float Rectangle::acreage(){
  float area;
  area = length * width;
  return area;
}

int main(){
  Rectangle a;
  float l,w, area;
  cin>>l>>w;
  a.set(l,w);
  area = a.acreage();
  cout<<area; 
  return 0;
}