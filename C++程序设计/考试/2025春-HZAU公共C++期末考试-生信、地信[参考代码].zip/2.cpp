#include<iostream>
#include<string>
using namespace std;

int main(){
    string passwd;
    cin>>passwd;
    int length = passwd.length();
    int c1=0,c2=0,c3=0,c4=0;
    for(int i=0;i<length;i++){
        char chr = char(passwd[i]);
        if(chr >= 65 && chr <= 65+25)
            c1 = 1;
        else if(chr >= 97 && chr <= 97+25)
            c2 = 1;
        else if(chr >= 48 && chr <= 48+9)
            c3 = 1;
        else
            c4 = 1;
    }
    if(length>=8 && length<=15 && c1+c2+c3+c4>2){
        cout<<"yes"<<endl;
    }
    else{
        cout<<"no"<<endl;
    }
    return 0;
}