#include<iostream>
using namespace std;

int main(){
    int n, total;
    cin>>n;
    total = 0;
    for(int i=2;i<n+1;i++){
        if(n%i == 0 && i%2==0){
            cout<<i<<' ';
            total++;
        }
    }
    cout<<'\n'<<total<<endl;
    return 0;
}