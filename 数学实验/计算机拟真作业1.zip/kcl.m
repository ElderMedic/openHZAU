n0=rand(30,1);
s=110;
extra=zeros(30,1);
p1=125;
p2=150;
q1=150;
q2=250;
sb1=0;
sb2=0;
for d=1:30
    if extra(d)>0
        s=s+extra(d);
        extra(d)=0;
    end
    n(d)=99*n0(d);
    if s>=n(d)
        s=s-n(d);
        sb1=0.5*s;
    else s=0
        sb1=0.5*s+1.6*(n(d)-s);
    end
    if s<p1
        extra(d+3)=q1
        sb1=sb1+75;
    end
end
for d=1:30
    if extra(d)>0
        s=s+extra(d);
        extra(d)=0;
    end
    n(d)=99*n0(d);
    if s>=n(d)
        s=s-n(d);
        sb2=0.5*s;
    else s=0
        sb2=0.5*s+1.6*(n(d)-s);
    end
    if s<p2
        extra(d+3)=q2
        sb2=sb2+75;
    end
end